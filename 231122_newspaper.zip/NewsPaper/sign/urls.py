from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView

app_name = 'sign'
urlpatterns = [
   path('login/',
       LoginView.as_view(template_name='sign/templates/login.html'),
       name='login'),
   path('logout/',
       LogoutView.as_view(template_name='sign/templates/logout.html'),
       name='logout'),
]